//
//  SceneKitAvailability.h
//  SceneKit
//
//  Copyright © 2017-2018 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#define SCN_EXPORT __attribute__((visibility("default"))) FOUNDATION_EXTERN

/*
	File:           AVAudioSession.h
	Framework:      AVFoundation
	
	Copyright 2016 Apple Inc. All rights reserved.
*/

#if __has_include(<AVFAudio/AVAudioSession.h>)
#import <AVFAudio/AVAudioSession.h>
#endif


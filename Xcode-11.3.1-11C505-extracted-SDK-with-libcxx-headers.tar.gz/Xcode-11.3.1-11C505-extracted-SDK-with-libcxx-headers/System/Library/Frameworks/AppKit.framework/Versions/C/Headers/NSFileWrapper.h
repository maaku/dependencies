/*
        NSFileWrapper.h
        Application Kit
        Copyright (c) 1995-2019, Apple Inc.
        All rights reserved.
*/

#warning NSFileWrapper has been moved to Foundation. Import <Foundation/Foundation.h> instead of <AppKit/NSFileWrapper.h>.

#import <Foundation/NSFileWrapper.h>

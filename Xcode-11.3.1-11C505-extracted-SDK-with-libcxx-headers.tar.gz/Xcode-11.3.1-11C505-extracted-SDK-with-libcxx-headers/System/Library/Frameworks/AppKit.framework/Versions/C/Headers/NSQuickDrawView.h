/*
        NSQuickDrawView.h
        Application Kit
        Copyright (c) 1999-2019, Apple Inc.
        All rights reserved.
*/

#warning NSQuickDrawView is deprecated, and does not exist on 64-bit architectures. This header will be removed from the framework in a future release.

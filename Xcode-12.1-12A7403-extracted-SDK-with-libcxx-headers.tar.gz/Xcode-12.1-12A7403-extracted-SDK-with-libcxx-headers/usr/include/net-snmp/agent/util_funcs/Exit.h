/*
 *  Exit.h:  verbose terminaion routine
 */
#ifndef _MIBGROUP_UTIL_FUNCS_EXIT_H
#define _MIBGROUP_UTIL_FUNCS_EXIT_H

#ifdef __cplusplus
extern "C" {
#endif

void            Exit(int);

#ifdef __cplusplus
}
#endif

#endif                          /* _MIBGROUP_UTIL_FUNCS_EXIT_H */

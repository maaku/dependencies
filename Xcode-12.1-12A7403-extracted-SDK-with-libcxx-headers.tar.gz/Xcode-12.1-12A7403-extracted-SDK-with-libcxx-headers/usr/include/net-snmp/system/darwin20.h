/* This is a place for the changes needed to get net_snmp runnning on darwin19
   Currently this just entails including darwin19.h, Yes we are still kicking this can down the road.
*/

#include "darwin19.h"

#ifndef darwin20
#   define darwin20 darwin
#endif



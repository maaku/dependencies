/* This is a place for the changes needed to get net_snmp runnning on darwin19
   Currently this just entails including darwin18.h, Yes we are still kicking this can down the road.
*/

#include "darwin18.h"

#ifndef darwin19
#   define darwin19 darwin
#endif



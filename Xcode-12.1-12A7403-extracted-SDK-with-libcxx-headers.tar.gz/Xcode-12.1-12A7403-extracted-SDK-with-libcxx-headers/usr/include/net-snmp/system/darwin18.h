/* This is a place for the changes needed to get net_snmp runnning on darwin18
   Currently this just entails including darwin17.h, Yes we are still kicking this can down the road.
*/

#include "darwin17.h"

#ifndef darwin18
#   define darwin18 darwin
#endif



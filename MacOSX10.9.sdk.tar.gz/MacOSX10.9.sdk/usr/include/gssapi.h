/* 
 * Wrapper so that #include <gssapi.h> will work without special include
 * paths.
 */
#include <gssapi/gssapi.h>

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	TC_SECTION	257
#define	TC_RAW	258
#define	TC_CONSTANT	259
#define	TC_NUMBER	260
#define	TC_STRING	261
#define	TC_WHITESPACE	262
#define	TC_LABEL	263
#define	TC_OFFSET	264
#define	TC_DOLLAR_CURLY	265
#define	TC_VARNAME	266
#define	TC_QUOTED_STRING	267
#define	BOOL_TRUE	268
#define	BOOL_FALSE	269
#define	END_OF_LINE	270

